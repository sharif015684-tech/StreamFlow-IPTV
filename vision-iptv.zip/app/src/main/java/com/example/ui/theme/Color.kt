package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Obsidian & Cinema Dark Palette
val IptvBackground = Color(0xFF070A11)
val IptvSurface = Color(0xFF0F1422)
val IptvSurfaceElevated = Color(0xFF171F34)
val IptvSurfaceHighlight = Color(0xFF212C48)
val IptvBorder = Color(0xFF253352)
val IptvBorderSubtle = Color(0xFF192338)

// Neon & Brand Accents
val CyanNeon = Color(0xFF00E5FF)
val CyanNeonDark = Color(0xFF00B4D8)
val CyanNeonGlow = Color(0x3300E5FF)

val IndigoAccent = Color(0xFF7C4DFF)
val IndigoGlow = Color(0x337C4DFF)

val AmberWarning = Color(0xFFFFB300)
val CoralError = Color(0xFFFF4D4D)
val EmeraldLive = Color(0xFF10B981)
val EmeraldLiveGlow = Color(0x3310B981)

// Text Colors
val TextPrimary = Color(0xFFF8FAFC)
val TextSecondary = Color(0xFF94A3B8)
val TextMuted = Color(0xFF64748B)
val TextOverlay = Color(0xFFFFFFFF)
