package com.example.ui.theme

import android.app.Activity
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.SideEffect
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalView
import androidx.core.view.WindowCompat

private val DarkColorScheme = darkColorScheme(
    primary = CyanNeon,
    onPrimary = IptvBackground,
    primaryContainer = CyanNeonDark,
    onPrimaryContainer = TextPrimary,
    secondary = IndigoAccent,
    onSecondary = TextPrimary,
    secondaryContainer = IptvSurfaceElevated,
    onSecondaryContainer = TextPrimary,
    tertiary = EmeraldLive,
    onTertiary = IptvBackground,
    background = IptvBackground,
    onBackground = TextPrimary,
    surface = IptvSurface,
    onSurface = TextPrimary,
    surfaceVariant = IptvSurfaceElevated,
    onSurfaceVariant = TextSecondary,
    outline = IptvBorder,
    outlineVariant = IptvBorderSubtle
)

@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    // IPTV is fundamentally designed for cinematic dark viewing
    val colorScheme = DarkColorScheme

    val view = LocalView.current
    if (!view.isInEditMode) {
        SideEffect {
            val window = (view.context as? Activity)?.window
            if (window != null) {
                val insetsController = WindowCompat.getInsetsController(window, view)
                insetsController.isAppearanceLightStatusBars = false
                insetsController.isAppearanceLightNavigationBars = false
            }
        }
    }

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}
