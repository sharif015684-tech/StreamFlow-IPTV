package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.RestartAlt
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.AdminDashboardStats
import com.example.model.ChannelEntity
import com.example.model.ChannelStatus
import com.example.model.ScanProgressState
import com.example.ui.components.AdminStatMetricCard
import com.example.ui.components.LiveStatusBadge
import com.example.ui.components.ResolutionBadge
import com.example.ui.components.ScanProgressWidget
import com.example.ui.theme.AmberWarning
import com.example.ui.theme.CoralError
import com.example.ui.theme.CyanNeon
import com.example.ui.theme.EmeraldLive
import com.example.ui.theme.IptvBackground
import com.example.ui.theme.IptvBorder
import com.example.ui.theme.IptvSurface
import com.example.ui.theme.IptvSurfaceElevated
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun AdminScanScreen(
    adminStats: AdminDashboardStats,
    scanProgress: ScanProgressState,
    allChannels: List<ChannelEntity>,
    adminFilter: String,
    onSetAdminFilter: (String) -> Unit,
    onStartScan: () -> Unit,
    onRecheckDeadChannels: () -> Unit,
    onTestSingleChannel: (String) -> Unit,
    onImportM3u: (String, String) -> Unit,
    onResetDefaults: () -> Unit,
    modifier: Modifier = Modifier
) {
    var showImportDialog by remember { mutableStateOf(false) }
    var playlistNameInput by remember { mutableStateOf("Authorized Custom Source") }
    var playlistContentInput by remember {
        mutableStateOf(
            """#EXTM3U
#EXTINF:-1 tvg-id="bloomberg" tvg-name="Bloomberg Quicktake" group-title="News",Bloomberg Quicktake
https://live-manifest.bloomberg.com/live/hls/us_quicktake.m3u8
#EXTINF:-1 tvg-id="skynews" tvg-name="Sky News Live" group-title="News",Sky News Live
https://skynews-live.akamaized.net/hls/live/2002689/skynews_live/master.m3u8
#EXTINF:-1 tvg-id="broken_feed" tvg-name="Vintage Archive (Dead Feed)" group-title="Movies",Vintage Archive (Dead Feed)
https://httpstat.us/503
"""
        )
    }

    val timeFormat = remember { SimpleDateFormat("h:mm:ss a", Locale.getDefault()) }
    val lastScanStr = if (adminStats.lastScanTimestamp > 0) {
        timeFormat.format(Date(adminStats.lastScanTimestamp))
    } else {
        "Never"
    }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(IptvBackground)
            .padding(horizontal = 16.dp)
            .testTag("admin_scan_screen"),
        contentPadding = PaddingValues(top = 16.dp, bottom = 32.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Header
        item {
            Column {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "Admin Stream Control",
                            color = TextPrimary,
                            fontSize = 22.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "Smart Channel Filtering & Background Probe",
                            color = TextSecondary,
                            fontSize = 13.sp
                        )
                    }

                    Box(
                        modifier = Modifier
                            .background(Color(0x3300E5FF), RoundedCornerShape(8.dp))
                            .border(1.dp, Color(0x6600E5FF), RoundedCornerShape(8.dp))
                            .padding(horizontal = 10.dp, vertical = 4.dp)
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Filled.Security,
                                contentDescription = "Security Active",
                                tint = CyanNeon,
                                modifier = Modifier.size(14.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = "URL SHIELD ACTIVE",
                                color = CyanNeon,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }
        }

        // Stats Matrix (Requirements 8 & 9)
        item {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    AdminStatMetricCard(
                        title = "Total",
                        value = "${adminStats.totalChannels}",
                        accentColor = TextPrimary,
                        subtitle = "In database",
                        modifier = Modifier.weight(1f)
                    )
                    AdminStatMetricCard(
                        title = "Active",
                        value = "${adminStats.activeChannels}",
                        accentColor = EmeraldLive,
                        subtitle = "Visible to users",
                        modifier = Modifier.weight(1f)
                    )
                    AdminStatMetricCard(
                        title = "Inactive",
                        value = "${adminStats.inactiveChannels}",
                        accentColor = CoralError,
                        subtitle = "Hidden from users",
                        modifier = Modifier.weight(1f)
                    )
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    AdminStatMetricCard(
                        title = "Checking",
                        value = "${adminStats.checkingChannels}",
                        accentColor = AmberWarning,
                        subtitle = "In flight",
                        modifier = Modifier.weight(1f)
                    )
                    AdminStatMetricCard(
                        title = "Last Scan",
                        value = lastScanStr,
                        accentColor = CyanNeon,
                        subtitle = "Avg ${adminStats.averageResponseTimeMs}ms latency",
                        modifier = Modifier.weight(2f)
                    )
                }
            }
        }

        // Scan Progress Widget
        item {
            ScanProgressWidget(state = scanProgress)
        }

        // Quick Admin Actions
        item {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Button(
                        onClick = onStartScan,
                        enabled = !scanProgress.isScanning,
                        colors = ButtonDefaults.buttonColors(
                            containerColor = CyanNeon,
                            contentColor = IptvBackground
                        ),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier
                            .weight(1f)
                            .height(46.dp)
                            .testTag("admin_start_scan_button")
                    ) {
                        Icon(
                            imageVector = Icons.Filled.Refresh,
                            contentDescription = "Scan",
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Validate All", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                    }

                    OutlinedButton(
                        onClick = onRecheckDeadChannels,
                        enabled = !scanProgress.isScanning && adminStats.inactiveChannels > 0,
                        colors = ButtonDefaults.outlinedButtonColors(
                            contentColor = AmberWarning
                        ),
                        border = androidx.compose.foundation.BorderStroke(1.dp, AmberWarning),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier
                            .weight(1f)
                            .height(46.dp)
                            .testTag("admin_recheck_dead_button")
                    ) {
                        Icon(
                            imageVector = Icons.Filled.Warning,
                            contentDescription = "Recheck",
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Recheck Inactive", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                    }
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    OutlinedButton(
                        onClick = { showImportDialog = true },
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = TextPrimary),
                        border = androidx.compose.foundation.BorderStroke(1.dp, IptvBorder),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier
                            .weight(1f)
                            .height(44.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Filled.Add,
                            contentDescription = "Import",
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Import M3U", fontSize = 12.sp)
                    }

                    OutlinedButton(
                        onClick = onResetDefaults,
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = TextSecondary),
                        border = androidx.compose.foundation.BorderStroke(1.dp, IptvBorder),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier
                            .weight(1f)
                            .height(44.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Filled.RestartAlt,
                            contentDescription = "Reset",
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Reset Feeds", fontSize = 12.sp)
                    }
                }
            }
        }

        // Filter Bar
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                listOf("ALL", "ACTIVE", "INACTIVE", "CHECKING").forEach { filter ->
                    val isSelected = adminFilter == filter
                    FilterChip(
                        selected = isSelected,
                        onClick = { onSetAdminFilter(filter) },
                        label = {
                            Text(
                                text = filter,
                                fontSize = 12.sp,
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium
                            )
                        },
                        colors = FilterChipDefaults.filterChipColors(
                            containerColor = IptvSurfaceElevated,
                            labelColor = TextSecondary,
                            selectedContainerColor = when (filter) {
                                "ACTIVE" -> EmeraldLive
                                "INACTIVE" -> CoralError
                                "CHECKING" -> AmberWarning
                                else -> CyanNeon
                            },
                            selectedLabelColor = IptvBackground
                        ),
                        border = FilterChipDefaults.filterChipBorder(
                            enabled = true,
                            selected = isSelected,
                            borderColor = IptvBorder,
                            selectedBorderColor = Color.Transparent
                        ),
                        shape = RoundedCornerShape(10.dp)
                    )
                }
            }
        }

        // Channel Audit Inspection List
        items(allChannels, key = { it.id }) { channel ->
            AdminChannelAuditCard(
                channel = channel,
                onRetest = { onTestSingleChannel(channel.id) }
            )
        }
    }

    // Import M3U Dialog
    if (showImportDialog) {
        AlertDialog(
            onDismissRequest = { showImportDialog = false },
            title = {
                Text(
                    text = "Import Authorized M3U Playlist",
                    color = TextPrimary,
                    fontWeight = FontWeight.Bold
                )
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(
                        text = "The playlist will be parsed and each stream verified before publishing to users.",
                        color = TextSecondary,
                        fontSize = 12.sp
                    )

                    OutlinedTextField(
                        value = playlistNameInput,
                        onValueChange = { playlistNameInput = it },
                        label = { Text("Playlist Name") },
                        singleLine = true,
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = CyanNeon,
                            unfocusedBorderColor = IptvBorder,
                            focusedTextColor = TextPrimary,
                            unfocusedTextColor = TextPrimary
                        ),
                        modifier = Modifier.fillMaxWidth()
                    )

                    OutlinedTextField(
                        value = playlistContentInput,
                        onValueChange = { playlistContentInput = it },
                        label = { Text("M3U Content / Streams") },
                        minLines = 4,
                        maxLines = 6,
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = CyanNeon,
                            unfocusedBorderColor = IptvBorder,
                            focusedTextColor = TextPrimary,
                            unfocusedTextColor = TextPrimary
                        ),
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        onImportM3u(playlistNameInput, playlistContentInput)
                        showImportDialog = false
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = CyanNeon)
                ) {
                    Text("Parse & Scan", color = IptvBackground, fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { showImportDialog = false }) {
                    Text("Cancel", color = TextSecondary)
                }
            },
            containerColor = IptvSurfaceElevated
        )
    }
}

@Composable
fun AdminChannelAuditCard(
    channel: ChannelEntity,
    onRetest: () -> Unit
) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .background(IptvSurface)
            .border(
                1.dp,
                if (channel.channelStatus == ChannelStatus.ACTIVE) IptvBorder else Color(0x44FF4D4D),
                RoundedCornerShape(16.dp)
            )
            .padding(14.dp)
    ) {
        Column {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Text(
                            text = channel.name,
                            color = TextPrimary,
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Bold,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                        LiveStatusBadge(status = channel.channelStatus)
                        ResolutionBadge(resolution = channel.resolution)
                    }

                    Spacer(modifier = Modifier.height(2.dp))

                    Text(
                        text = "${channel.category} • ${if (channel.responseTimeMs > 0) "${channel.responseTimeMs}ms" else "unreachable"}",
                        color = TextSecondary,
                        fontSize = 11.sp
                    )
                }

                IconButton(
                    onClick = onRetest,
                    modifier = Modifier.size(36.dp)
                ) {
                    Icon(
                        imageVector = Icons.Filled.Refresh,
                        contentDescription = "Retest stream",
                        tint = CyanNeon
                    )
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Secure Masked Stream URL (Requirement 11)
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(Color(0xFF090D18), RoundedCornerShape(8.dp))
                    .padding(horizontal = 8.dp, vertical = 5.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Filled.Security,
                        contentDescription = "Masked",
                        tint = TextMuted,
                        modifier = Modifier.size(12.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "Source: ${channel.maskedStreamUrl}",
                        color = Color(0xFF64748B),
                        fontSize = 11.sp,
                        fontFamily = FontFamily.Monospace,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            }

            // Probe Diagnostics
            if (!channel.failureReason.isNullOrBlank()) {
                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = "Diagnostics: ${channel.failureReason}",
                    color = CoralError,
                    fontSize = 11.sp,
                    fontFamily = FontFamily.Monospace
                )
            }
        }
    }
}
