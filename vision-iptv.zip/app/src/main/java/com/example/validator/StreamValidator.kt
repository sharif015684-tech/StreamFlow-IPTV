package com.example.validator

import com.example.model.ChannelStatus
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.HttpUrl.Companion.toHttpUrlOrNull
import okhttp3.OkHttpClient
import okhttp3.Request
import java.io.BufferedReader
import java.io.StringReader
import java.util.concurrent.TimeUnit

data class StreamValidationResult(
    val status: ChannelStatus,
    val responseTimeMs: Long,
    val failureReason: String? = null
)

class StreamValidator(
    private val client: OkHttpClient = OkHttpClient.Builder()
        .connectTimeout(5, TimeUnit.SECONDS)
        .readTimeout(5, TimeUnit.SECONDS)
        .followRedirects(true)
        .build()
) {

    private val userAgent = "VisionIPTV/1.0 (Android; ExoPlayer HLS Prober; Linux)"

    suspend fun validateStream(url: String): StreamValidationResult = withContext(Dispatchers.IO) {
        val startTime = System.currentTimeMillis()

        // Handle internal mock demo URLs safely
        if (url.contains("invalid-stream-iptv-mock.internal")) {
            return@withContext StreamValidationResult(
                status = ChannelStatus.INACTIVE,
                responseTimeMs = 0L,
                failureReason = "Stream DNS resolution failed (Host unreachable)"
            )
        }

        try {
            val request = Request.Builder()
                .url(url)
                .header("User-Agent", userAgent)
                .header("Accept", "*/*")
                .header("Range", "bytes=0-8192") // Fast probe to prevent downloading entire stream
                .get()
                .build()

            client.newCall(request).execute().use { response ->
                val responseTime = System.currentTimeMillis() - startTime
                val code = response.code

                if (!response.isSuccessful && code != 206) {
                    val errorCategory = when (code) {
                        403, 401 -> "HTTP $code: Stream access denied or authentication key expired"
                        404 -> "HTTP 404: Stream endpoint or channel offline"
                        500, 502, 503 -> "HTTP $code: IPTV upstream relay server error"
                        else -> "HTTP $code: Server rejected stream request"
                    }
                    return@withContext StreamValidationResult(
                        status = ChannelStatus.INACTIVE,
                        responseTimeMs = responseTime,
                        failureReason = errorCategory
                    )
                }

                val contentType = response.header("Content-Type")?.lowercase() ?: ""
                val body = response.body?.string() ?: ""

                // Check for deceptive HTTP 200 pages (HTML portals / JSON errors)
                if (contentType.contains("text/html") && !body.contains("#EXTM3U")) {
                    return@withContext StreamValidationResult(
                        status = ChannelStatus.INACTIVE,
                        responseTimeMs = responseTime,
                        failureReason = "Deceptive 200: Server returned HTML error landing page instead of video"
                    )
                }

                val isHls = url.contains(".m3u8", ignoreCase = true) ||
                        contentType.contains("mpegurl") ||
                        body.contains("#EXTM3U")

                if (isHls) {
                    // Validate HLS Manifest Structure
                    if (!body.contains("#EXTM3U")) {
                        return@withContext StreamValidationResult(
                            status = ChannelStatus.INACTIVE,
                            responseTimeMs = responseTime,
                            failureReason = "Invalid HLS: Manifest missing mandatory #EXTM3U tag"
                        )
                    }

                    // Deep probe: Verify sub-stream or segment availability
                    val firstSegmentOrSubStream = extractFirstMediaUri(body, url)
                    if (firstSegmentOrSubStream != null) {
                        val segmentValid = verifySegmentReachable(firstSegmentOrSubStream)
                        if (!segmentValid) {
                            return@withContext StreamValidationResult(
                                status = ChannelStatus.INACTIVE,
                                responseTimeMs = responseTime,
                                failureReason = "HLS media segment probe failed: Chunk returned 404/broken"
                            )
                        }
                    }

                    return@withContext StreamValidationResult(
                        status = ChannelStatus.ACTIVE,
                        responseTimeMs = responseTime,
                        failureReason = null
                    )
                } else {
                    // Direct media stream check (.mp4, .ts, etc.)
                    val isMedia = contentType.startsWith("video/") ||
                            contentType.startsWith("audio/") ||
                            contentType.contains("octet-stream") ||
                            url.endsWith(".mp4", ignoreCase = true) ||
                            url.endsWith(".ts", ignoreCase = true)

                    if (!isMedia) {
                        return@withContext StreamValidationResult(
                            status = ChannelStatus.INACTIVE,
                            responseTimeMs = responseTime,
                            failureReason = "Invalid media payload: Content-Type '$contentType' is not playable"
                        )
                    }

                    return@withContext StreamValidationResult(
                        status = ChannelStatus.ACTIVE,
                        responseTimeMs = responseTime,
                        failureReason = null
                    )
                }
            }
        } catch (e: Exception) {
            val responseTime = System.currentTimeMillis() - startTime
            val reason = when {
                e is java.net.SocketTimeoutException -> "Stream probe timed out after 5000ms"
                e is java.net.UnknownHostException -> "DNS lookup failed: Stream host does not exist"
                e is java.net.ConnectException -> "Connection refused by target IPTV server"
                else -> "Connection error: ${e.javaClass.simpleName}"
            }
            StreamValidationResult(
                status = ChannelStatus.INACTIVE,
                responseTimeMs = responseTime,
                failureReason = reason
            )
        }
    }

    private fun extractFirstMediaUri(manifestText: String, parentUrl: String): String? {
        val parentHttpUrl = parentUrl.toHttpUrlOrNull() ?: return null
        BufferedReader(StringReader(manifestText)).use { reader ->
            var line = reader.readLine()
            while (line != null) {
                val trimmed = line.trim()
                if (trimmed.isNotEmpty() && !trimmed.startsWith("#")) {
                    return try {
                        parentHttpUrl.resolve(trimmed)?.toString()
                    } catch (e: Exception) {
                        null
                    }
                }
                line = reader.readLine()
            }
        }
        return null
    }

    private fun verifySegmentReachable(segmentUrl: String): Boolean {
        return try {
            val probeReq = Request.Builder()
                .url(segmentUrl)
                .header("User-Agent", userAgent)
                .header("Range", "bytes=0-512")
                .head() // Fast HEAD check first
                .build()

            client.newCall(probeReq).execute().use { response ->
                response.isSuccessful || response.code == 206 || response.code == 416
            }
        } catch (e: Exception) {
            // Some CDN servers reject HEAD requests; fallback to small GET probe
            try {
                val getReq = Request.Builder()
                    .url(segmentUrl)
                    .header("User-Agent", userAgent)
                    .header("Range", "bytes=0-256")
                    .get()
                    .build()
                client.newCall(getReq).execute().use { resp ->
                    resp.isSuccessful || resp.code == 206
                }
            } catch (e2: Exception) {
                false
            }
        }
    }
}
