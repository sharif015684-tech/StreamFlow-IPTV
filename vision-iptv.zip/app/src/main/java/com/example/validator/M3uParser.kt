package com.example.validator

import com.example.model.ChannelEntity
import com.example.model.ChannelStatus
import java.io.BufferedReader
import java.io.StringReader
import java.util.UUID

object M3uParser {

    fun parse(m3uContent: String): List<ChannelEntity> {
        val channels = mutableListOf<ChannelEntity>()
        val reader = BufferedReader(StringReader(m3uContent))

        var line = reader.readLine()
        var currentName: String? = null
        var currentLogo: String? = null
        var currentCategory = "General"
        var currentResolution = "HD"

        while (line != null) {
            val trimmed = line.trim()
            if (trimmed.startsWith("#EXTINF:", ignoreCase = true)) {
                // Parse attributes
                currentLogo = extractAttribute(trimmed, "tvg-logo")
                val groupTitle = extractAttribute(trimmed, "group-title")
                if (!groupTitle.isNullOrBlank()) {
                    currentCategory = groupTitle
                }

                // Extract Channel Name (after last comma)
                val commaIndex = trimmed.lastIndexOf(',')
                currentName = if (commaIndex != -1 && commaIndex < trimmed.length - 1) {
                    trimmed.substring(commaIndex + 1).trim()
                } else {
                    extractAttribute(trimmed, "tvg-name") ?: "IPTV Channel ${channels.size + 1}"
                }

                // Infer resolution
                currentResolution = when {
                    trimmed.contains("4k", ignoreCase = true) || trimmed.contains("uhd", ignoreCase = true) -> "4K UHD"
                    trimmed.contains("fhd", ignoreCase = true) || trimmed.contains("1080", ignoreCase = true) -> "1080p FHD"
                    trimmed.contains("hd", ignoreCase = true) || trimmed.contains("720", ignoreCase = true) -> "720p HD"
                    else -> "HD"
                }
            } else if (trimmed.isNotEmpty() && !trimmed.startsWith("#")) {
                // This is a stream URL line
                val streamUrl = trimmed
                val name = currentName ?: "Channel ${channels.size + 1}"
                val id = "custom_" + UUID.nameUUIDFromBytes(streamUrl.toByteArray()).toString().take(12)

                channels.add(
                    ChannelEntity(
                        id = id,
                        name = name,
                        streamUrl = streamUrl,
                        logoUrl = currentLogo,
                        category = normalizeCategory(currentCategory),
                        epgTitle = "Live Scheduled Program",
                        epgDescription = "Direct broadcast stream from $name",
                        epgDurationMinutes = 60,
                        epgProgressPercentage = 0.5f,
                        status = ChannelStatus.UNKNOWN.name,
                        resolution = currentResolution,
                        isCustomPlaylist = true
                    )
                )

                // Reset for next
                currentName = null
                currentLogo = null
                currentCategory = "General"
                currentResolution = "HD"
            }
            line = reader.readLine()
        }

        return channels
    }

    private fun extractAttribute(line: String, attrName: String): String? {
        val pattern = """$attrName="([^"]*)"""".toRegex(RegexOption.IGNORE_CASE)
        val match = pattern.find(line)
        return match?.groups?.get(1)?.value?.takeIf { it.isNotBlank() }
    }

    private fun normalizeCategory(category: String): String {
        val lower = category.lowercase()
        return when {
            lower.contains("sport") -> "Sports"
            lower.contains("news") -> "News"
            lower.contains("movie") || lower.contains("cinema") || lower.contains("film") -> "Movies"
            lower.contains("music") -> "Music"
            lower.contains("doc") || lower.contains("nature") || lower.contains("science") -> "Documentary"
            lower.contains("kid") || lower.contains("child") || lower.contains("cartoon") || lower.contains("anim") -> "Kids"
            lower.contains("enter") || lower.contains("series") || lower.contains("show") -> "Entertainment"
            else -> category.trim().takeIf { it.isNotEmpty() } ?: "General"
        }
    }
}
