package com.example.model

import androidx.room.Entity
import androidx.room.PrimaryKey

enum class ChannelStatus {
    ACTIVE,
    INACTIVE,
    CHECKING,
    UNKNOWN
}

@Entity(tableName = "channels")
data class ChannelEntity(
    @PrimaryKey val id: String,
    val name: String,
    val streamUrl: String, // Kept private, masked in UI
    val logoUrl: String? = null,
    val category: String = "General",
    val epgTitle: String = "Live Broadcast",
    val epgDescription: String = "Standard live transmission stream.",
    val epgDurationMinutes: Int = 60,
    val epgProgressPercentage: Float = 0.45f,
    val status: String = ChannelStatus.UNKNOWN.name,
    val lastCheckedTimestamp: Long = 0L,
    val lastSuccessTimestamp: Long = 0L,
    val responseTimeMs: Long = 0L,
    val failureReason: String? = null,
    val resolution: String = "HD",
    val isFavorite: Boolean = false,
    val lastWatchedTimestamp: Long = 0L,
    val watchCount: Int = 0,
    val isFeatured: Boolean = false,
    val isCustomPlaylist: Boolean = false
) {
    val channelStatus: ChannelStatus
        get() = try {
            ChannelStatus.valueOf(status)
        } catch (e: Exception) {
            ChannelStatus.UNKNOWN
        }

    val maskedStreamUrl: String
        get() = maskUrl(streamUrl)

    companion object {
        fun maskUrl(url: String): String {
            if (url.isBlank()) return "https://auth.stream.provider/••••••••"
            return try {
                val host = java.net.URI(url).host?.takeIf { it.isNotBlank() }
                    ?: url.substringAfter("://", "").substringBefore("/").substringBefore(":")
                if (host.isNotBlank()) {
                    "https://$host/••••••••"
                } else {
                    "https://auth.stream.provider/••••••••"
                }
            } catch (e: Exception) {
                val fallbackHost = url.substringAfter("://", "").substringBefore("/").substringBefore(":")
                if (fallbackHost.isNotBlank()) {
                    "https://$fallbackHost/••••••••"
                } else {
                    "https://auth.stream.provider/••••••••"
                }
            }
        }
    }
}
