package com.example.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "playlists")
data class PlaylistEntity(
    @PrimaryKey val id: String,
    val name: String,
    val maskedUrl: String,
    val encryptedUrl: String, // Kept private, never exposed in client UI
    val lastScanTimestamp: Long = 0L,
    val totalChannels: Int = 0,
    val activeChannels: Int = 0,
    val inactiveChannels: Int = 0,
    val autoCheckIntervalMinutes: Int = 30
)

data class ScanProgressState(
    val isScanning: Boolean = false,
    val totalFound: Int = 0,
    val checkedCount: Int = 0,
    val activeCount: Int = 0,
    val inactiveCount: Int = 0,
    val currentChannelName: String? = null,
    val currentChannelIndex: Int = 0,
    val progress: Float = 0f,
    val lastScanCompletedTimestamp: Long = 0L,
    val lastScanMessage: String = "Ready to validate"
)

data class AdminDashboardStats(
    val totalChannels: Int = 0,
    val activeChannels: Int = 0,
    val inactiveChannels: Int = 0,
    val checkingChannels: Int = 0,
    val lastScanTimestamp: Long = 0L,
    val averageResponseTimeMs: Long = 0L
)
