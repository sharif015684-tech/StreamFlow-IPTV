package com.example.data

import com.example.model.AdminDashboardStats
import com.example.model.ChannelEntity
import com.example.model.ChannelStatus
import com.example.model.PlaylistEntity
import com.example.model.ScanProgressState
import com.example.validator.M3uParser
import com.example.validator.StreamValidator
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import kotlinx.coroutines.withContext

class ChannelRepository(
    private val dao: ChannelDao,
    private val validator: StreamValidator = StreamValidator()
) {
    private val repositoryScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    private val _scanProgress = MutableStateFlow(ScanProgressState())
    val scanProgress: StateFlow<ScanProgressState> = _scanProgress.asStateFlow()

    // Public User Flows (Active Playable Only)
    val activeChannels: Flow<List<ChannelEntity>> = dao.getActiveChannels()
    val activeFavorites: Flow<List<ChannelEntity>> = dao.getActiveFavorites()
    val activeRecentlyWatched: Flow<List<ChannelEntity>> = dao.getActiveRecentlyWatched()
    val activeFeatured: Flow<List<ChannelEntity>> = dao.getActiveFeatured()

    // Admin Flow (Full Database audit)
    val allChannels: Flow<List<ChannelEntity>> = dao.getAllChannels()

    val adminStats: Flow<AdminDashboardStats> = allChannels.map { list ->
        val total = list.size
        val active = list.count { it.status == ChannelStatus.ACTIVE.name }
        val inactive = list.count { it.status == ChannelStatus.INACTIVE.name }
        val checking = list.count { it.status == ChannelStatus.CHECKING.name }
        val avgLatency = if (active > 0) {
            list.filter { it.status == ChannelStatus.ACTIVE.name }.map { it.responseTimeMs }.average().toLong()
        } else 0L

        AdminDashboardStats(
            totalChannels = total,
            activeChannels = active,
            inactiveChannels = inactive,
            checkingChannels = checking,
            lastScanTimestamp = list.maxOfOrNull { it.lastCheckedTimestamp } ?: 0L,
            averageResponseTimeMs = avgLatency
        )
    }

    init {
        repositoryScope.launch {
            seedDefaultChannelsIfEmpty()
        }
    }

    private suspend fun seedDefaultChannelsIfEmpty() = withContext(Dispatchers.IO) {
        val count = dao.getAllChannelsList().size
        if (count == 0) {
            val defaults = DefaultChannels.getInitialChannels()
            dao.insertChannels(defaults)

            val initialPlaylist = PlaylistEntity(
                id = "pl_default_authorized",
                name = "Authorized Global Live Network",
                maskedUrl = "https://auth-stream-network.global/••••••••",
                encryptedUrl = "https://auth-stream-network.global/live/master_feed.m3u8",
                lastScanTimestamp = System.currentTimeMillis() - 120000,
                totalChannels = defaults.size,
                activeChannels = defaults.count { it.status == ChannelStatus.ACTIVE.name },
                inactiveChannels = defaults.count { it.status == ChannelStatus.INACTIVE.name }
            )
            dao.insertPlaylist(initialPlaylist)
        }
    }

    suspend fun toggleFavorite(channelId: String, isFavorite: Boolean) = withContext(Dispatchers.IO) {
        dao.setFavorite(channelId, isFavorite)
    }

    suspend fun recordWatched(channelId: String) = withContext(Dispatchers.IO) {
        dao.recordWatched(channelId, System.currentTimeMillis())
    }

    suspend fun getChannelById(channelId: String): ChannelEntity? = withContext(Dispatchers.IO) {
        dao.getChannelById(channelId)
    }

    suspend fun importM3uContent(name: String, m3uContent: String): Int = withContext(Dispatchers.IO) {
        val parsed = M3uParser.parse(m3uContent)
        if (parsed.isNotEmpty()) {
            dao.insertChannels(parsed)
            val playlist = PlaylistEntity(
                id = "pl_custom_" + System.currentTimeMillis(),
                name = name,
                maskedUrl = "https://auth-iptv-relay.net/••••••••",
                encryptedUrl = "https://auth-iptv-relay.net/secure_feed.m3u8",
                lastScanTimestamp = System.currentTimeMillis(),
                totalChannels = parsed.size,
                activeChannels = 0,
                inactiveChannels = 0
            )
            dao.insertPlaylist(playlist)
            // Trigger background verification
            startValidation(parsed)
        }
        parsed.size
    }

    suspend fun startValidation(targets: List<ChannelEntity>? = null) = withContext(Dispatchers.IO) {
        if (_scanProgress.value.isScanning) return@withContext

        val channelsToTest = targets ?: dao.getAllChannelsList()
        val total = channelsToTest.size
        if (total == 0) return@withContext

        _scanProgress.value = ScanProgressState(
            isScanning = true,
            totalFound = total,
            checkedCount = 0,
            activeCount = 0,
            inactiveCount = 0,
            currentChannelName = "Initializing verification...",
            progress = 0f,
            lastScanMessage = "Scanning playlist streams..."
        )

        // Safe concurrency: limit simultaneous checks to 4 requests
        val semaphore = Semaphore(4)
        var checked = 0
        var active = 0
        var inactive = 0

        channelsToTest.forEachIndexed { index, channel ->
            dao.markChecking(channel.id)

            _scanProgress.value = _scanProgress.value.copy(
                currentChannelName = channel.name,
                currentChannelIndex = index + 1,
                lastScanMessage = "Checking stream: ${channel.name}"
            )

            val result = semaphore.withPermit {
                validator.validateStream(channel.streamUrl)
            }

            val now = System.currentTimeMillis()
            dao.updateValidationResult(
                id = channel.id,
                status = result.status.name,
                failureReason = result.failureReason,
                responseTimeMs = result.responseTimeMs,
                timestamp = now
            )

            checked++
            if (result.status == ChannelStatus.ACTIVE) {
                active++
            } else {
                inactive++
            }

            val progressRatio = checked.toFloat() / total.toFloat()
            _scanProgress.value = _scanProgress.value.copy(
                checkedCount = checked,
                activeCount = active,
                inactiveCount = inactive,
                progress = progressRatio,
                lastScanMessage = "Active: $active | Inactive: $inactive"
            )
        }

        _scanProgress.value = ScanProgressState(
            isScanning = false,
            totalFound = total,
            checkedCount = checked,
            activeCount = active,
            inactiveCount = inactive,
            currentChannelName = null,
            progress = 1f,
            lastScanCompletedTimestamp = System.currentTimeMillis(),
            lastScanMessage = "Validation complete: $active active, $inactive inactive"
        )
    }

    suspend fun recheckInactiveChannels() = withContext(Dispatchers.IO) {
        val inactiveList = dao.getInactiveChannelsList()
        if (inactiveList.isNotEmpty()) {
            startValidation(inactiveList)
        }
    }

    suspend fun testSingleChannel(channelId: String): ChannelStatus = withContext(Dispatchers.IO) {
        val channel = dao.getChannelById(channelId) ?: return@withContext ChannelStatus.UNKNOWN
        dao.markChecking(channelId)
        val result = validator.validateStream(channel.streamUrl)
        dao.updateValidationResult(
            id = channel.id,
            status = result.status.name,
            failureReason = result.failureReason,
            responseTimeMs = result.responseTimeMs,
            timestamp = System.currentTimeMillis()
        )
        result.status
    }

    suspend fun resetToDefaultStreams() = withContext(Dispatchers.IO) {
        dao.deleteAllChannels()
        val defaults = DefaultChannels.getInitialChannels()
        dao.insertChannels(defaults)
    }
}
