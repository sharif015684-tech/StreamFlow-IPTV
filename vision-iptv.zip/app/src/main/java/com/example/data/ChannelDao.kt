package com.example.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.example.model.ChannelEntity
import com.example.model.PlaylistEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface ChannelDao {

    // Normal User Queries: STRICTLY ACTIVE CHANNELS ONLY
    @Query("SELECT * FROM channels WHERE status = 'ACTIVE' ORDER BY isFeatured DESC, watchCount DESC, name ASC")
    fun getActiveChannels(): Flow<List<ChannelEntity>>

    @Query("SELECT * FROM channels WHERE status = 'ACTIVE' AND isFavorite = 1 ORDER BY name ASC")
    fun getActiveFavorites(): Flow<List<ChannelEntity>>

    @Query("SELECT * FROM channels WHERE status = 'ACTIVE' AND lastWatchedTimestamp > 0 ORDER BY lastWatchedTimestamp DESC LIMIT 10")
    fun getActiveRecentlyWatched(): Flow<List<ChannelEntity>>

    @Query("SELECT * FROM channels WHERE status = 'ACTIVE' AND isFeatured = 1 LIMIT 5")
    fun getActiveFeatured(): Flow<List<ChannelEntity>>

    @Query("SELECT * FROM channels WHERE status = 'ACTIVE' AND category = :category ORDER BY watchCount DESC, name ASC")
    fun getActiveChannelsByCategory(category: String): Flow<List<ChannelEntity>>

    // Admin Queries: All channels including Inactive & Checking
    @Query("SELECT * FROM channels ORDER BY name ASC")
    fun getAllChannels(): Flow<List<ChannelEntity>>

    @Query("SELECT * FROM channels WHERE status = 'INACTIVE'")
    suspend fun getInactiveChannelsList(): List<ChannelEntity>

    @Query("SELECT * FROM channels WHERE status = 'ACTIVE'")
    suspend fun getActiveChannelsList(): List<ChannelEntity>

    @Query("SELECT * FROM channels")
    suspend fun getAllChannelsList(): List<ChannelEntity>

    @Query("SELECT * FROM channels WHERE id = :id LIMIT 1")
    suspend fun getChannelById(id: String): ChannelEntity?

    @Query("SELECT COUNT(*) FROM channels")
    fun getTotalChannelCount(): Flow<Int>

    @Query("SELECT COUNT(*) FROM channels WHERE status = 'ACTIVE'")
    fun getActiveChannelCount(): Flow<Int>

    @Query("SELECT COUNT(*) FROM channels WHERE status = 'INACTIVE'")
    fun getInactiveChannelCount(): Flow<Int>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertChannels(channels: List<ChannelEntity>)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertChannel(channel: ChannelEntity)

    @Update
    suspend fun updateChannel(channel: ChannelEntity)

    @Query("UPDATE channels SET status = :status, failureReason = :failureReason, responseTimeMs = :responseTimeMs, lastCheckedTimestamp = :timestamp, lastSuccessTimestamp = CASE WHEN :status = 'ACTIVE' THEN :timestamp ELSE lastSuccessTimestamp END WHERE id = :id")
    suspend fun updateValidationResult(
        id: String,
        status: String,
        failureReason: String?,
        responseTimeMs: Long,
        timestamp: Long
    )

    @Query("UPDATE channels SET status = 'CHECKING' WHERE id = :id")
    suspend fun markChecking(id: String)

    @Query("UPDATE channels SET isFavorite = :isFav WHERE id = :id")
    suspend fun setFavorite(id: String, isFav: Boolean)

    @Query("UPDATE channels SET lastWatchedTimestamp = :timestamp, watchCount = watchCount + 1 WHERE id = :id")
    suspend fun recordWatched(id: String, timestamp: Long)

    @Query("DELETE FROM channels WHERE isCustomPlaylist = 1")
    suspend fun clearCustomChannels()

    @Query("DELETE FROM channels")
    suspend fun deleteAllChannels()

    // Playlist queries
    @Query("SELECT * FROM playlists LIMIT 1")
    fun getActivePlaylist(): Flow<PlaylistEntity?>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPlaylist(playlist: PlaylistEntity)
}
