package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.LiveTv
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material.icons.filled.Tv
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material.icons.outlined.LiveTv
import androidx.compose.material.icons.outlined.Settings
import androidx.compose.material.icons.outlined.StarBorder
import androidx.compose.material.icons.outlined.Tune
import androidx.compose.material.icons.outlined.Tv
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.NavigationRail
import androidx.compose.material3.NavigationRailItem
import androidx.compose.material3.NavigationRailItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Snackbar
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.ui.player.LivePlayerScreen
import com.example.ui.screens.AdminScanScreen
import com.example.ui.screens.DashboardScreen
import com.example.ui.screens.FavoritesScreen
import com.example.ui.screens.LiveChannelsScreen
import com.example.ui.screens.SettingsScreen
import com.example.ui.theme.CyanNeon
import com.example.ui.theme.EmeraldLive
import com.example.ui.theme.IptvBackground
import com.example.ui.theme.IptvBorder
import com.example.ui.theme.IptvSurfaceElevated
import com.example.ui.theme.MyApplicationTheme
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.viewmodel.IptvViewModel
import com.example.viewmodel.NavigationTab

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme {
                MainApp()
            }
        }
    }
}

data class NavItem(
    val tab: NavigationTab,
    val title: String,
    val selectedIcon: ImageVector,
    val unselectedIcon: ImageVector
)

@Composable
fun MainApp(viewModel: IptvViewModel = viewModel()) {
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()
    val scanProgress by viewModel.scanProgress.collectAsStateWithLifecycle()
    val adminStats by viewModel.adminStats.collectAsStateWithLifecycle()

    val navItems = listOf(
        NavItem(NavigationTab.DASHBOARD, "Home", Icons.Filled.Tv, Icons.Outlined.Tv),
        NavItem(NavigationTab.LIVE_CHANNELS, "Live TV", Icons.Filled.LiveTv, Icons.Outlined.LiveTv),
        NavItem(NavigationTab.FAVORITES, "Favorites", Icons.Filled.Star, Icons.Outlined.StarBorder),
        NavItem(NavigationTab.ADMIN_SCAN, "Control", Icons.Filled.Tune, Icons.Outlined.Tune),
        NavItem(NavigationTab.SETTINGS, "Settings", Icons.Filled.Settings, Icons.Outlined.Settings)
    )

    // Full Screen Video Player Overlay
    if (uiState.selectedChannelForPlayback != null) {
        LivePlayerScreen(
            channel = uiState.selectedChannelForPlayback!!,
            activeChannels = uiState.activeChannels,
            onClosePlayer = { viewModel.closePlayer() },
            onSelectChannel = { viewModel.playChannel(it) },
            onToggleFavorite = { viewModel.toggleFavorite(it) }
        )
        return
    }

    BoxWithConstraints(modifier = Modifier.fillMaxSize().background(IptvBackground)) {
        val isTabletOrTv = maxWidth >= 720.dp

        Row(modifier = Modifier.fillMaxSize()) {
            // Adaptive Navigation Rail for Wide Screens / Tablets / Android TV
            if (isTabletOrTv) {
                NavigationRail(
                    modifier = Modifier
                        .fillMaxHeight()
                        .windowInsetsPadding(WindowInsets.statusBars),
                    containerColor = IptvSurfaceElevated,
                    contentColor = TextPrimary,
                    header = {
                        Box(
                            modifier = Modifier
                                .padding(12.dp)
                                .size(44.dp)
                                .background(Color(0xFF0F2B48), CircleShape)
                                .border(1.dp, CyanNeon, CircleShape),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Filled.Tv,
                                contentDescription = "Vision IPTV",
                                tint = CyanNeon,
                                modifier = Modifier.size(22.dp)
                            )
                        }
                    }
                ) {
                    navItems.forEach { item ->
                        val isSelected = uiState.currentTab == item.tab
                        NavigationRailItem(
                            selected = isSelected,
                            onClick = { viewModel.selectTab(item.tab) },
                            icon = {
                                Icon(
                                    imageVector = if (isSelected) item.selectedIcon else item.unselectedIcon,
                                    contentDescription = item.title
                                )
                            },
                            label = { Text(item.title, fontSize = 11.sp) },
                            colors = NavigationRailItemDefaults.colors(
                                selectedIconColor = IptvBackground,
                                indicatorColor = CyanNeon,
                                selectedTextColor = CyanNeon,
                                unselectedIconColor = TextSecondary,
                                unselectedTextColor = TextSecondary
                            )
                        )
                    }
                }
            }

            // Main Content Area
            Scaffold(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxHeight(),
                containerColor = IptvBackground,
                topBar = {
                    VisionTopAppBar(
                        activeChannelCount = uiState.activeChannels.size,
                        isScanning = scanProgress.isScanning,
                        onTriggerScan = { viewModel.startValidationScan() }
                    )
                },
                bottomBar = {
                    if (!isTabletOrTv) {
                        NavigationBar(
                            modifier = Modifier.windowInsetsPadding(WindowInsets.navigationBars),
                            containerColor = IptvSurfaceElevated,
                            contentColor = TextPrimary
                        ) {
                            navItems.forEach { item ->
                                val isSelected = uiState.currentTab == item.tab
                                NavigationBarItem(
                                    selected = isSelected,
                                    onClick = { viewModel.selectTab(item.tab) },
                                    icon = {
                                        Icon(
                                            imageVector = if (isSelected) item.selectedIcon else item.unselectedIcon,
                                            contentDescription = item.title,
                                            modifier = Modifier.size(22.dp)
                                        )
                                    },
                                    label = {
                                        Text(
                                            text = item.title,
                                            fontSize = 11.sp,
                                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                                        )
                                    },
                                    colors = NavigationBarItemDefaults.colors(
                                        selectedIconColor = IptvBackground,
                                        indicatorColor = CyanNeon,
                                        selectedTextColor = CyanNeon,
                                        unselectedIconColor = TextSecondary,
                                        unselectedTextColor = TextSecondary
                                    ),
                                    modifier = Modifier.testTag("nav_${item.tab.name.lowercase()}")
                                )
                            }
                        }
                    }
                }
            ) { innerPadding ->
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(innerPadding)
                ) {
                    when (uiState.currentTab) {
                        NavigationTab.DASHBOARD -> DashboardScreen(
                            uiState = uiState,
                            onSelectChannel = { viewModel.playChannel(it) },
                            onToggleFavorite = { viewModel.toggleFavorite(it) },
                            onSelectCategory = { viewModel.selectCategory(it) }
                        )

                        NavigationTab.LIVE_CHANNELS -> LiveChannelsScreen(
                            uiState = uiState,
                            onSelectChannel = { viewModel.playChannel(it) },
                            onToggleFavorite = { viewModel.toggleFavorite(it) },
                            onSearchQueryChange = { viewModel.setSearchQuery(it) },
                            onSelectCategory = { viewModel.selectCategory(it) }
                        )

                        NavigationTab.FAVORITES -> FavoritesScreen(
                            uiState = uiState,
                            onSelectChannel = { viewModel.playChannel(it) },
                            onToggleFavorite = { viewModel.toggleFavorite(it) }
                        )

                        NavigationTab.ADMIN_SCAN -> AdminScanScreen(
                            adminStats = adminStats,
                            scanProgress = scanProgress,
                            allChannels = uiState.allChannelsForAdmin,
                            adminFilter = uiState.adminFilter,
                            onSetAdminFilter = { viewModel.setAdminFilter(it) },
                            onStartScan = { viewModel.startValidationScan() },
                            onRecheckDeadChannels = { viewModel.recheckDeadChannels() },
                            onTestSingleChannel = { viewModel.testSingleChannel(it) },
                            onImportM3u = { name, content -> viewModel.importM3uPlaylist(name, content) },
                            onResetDefaults = { viewModel.resetToDefaults() }
                        )

                        NavigationTab.SETTINGS -> SettingsScreen(
                            uiState = uiState,
                            onToggleAdminMode = { viewModel.toggleAdminMode() },
                            onResetDefaults = { viewModel.resetToDefaults() }
                        )
                    }

                    // User Friendly Notice Toast (Never technical raw exceptions!)
                    if (uiState.userFriendlyMessage != null) {
                        Box(
                            modifier = Modifier
                                .align(Alignment.BottomCenter)
                                .padding(16.dp)
                        ) {
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(12.dp))
                                    .background(Color(0xFF1E2638))
                                    .border(1.dp, CyanNeon, RoundedCornerShape(12.dp))
                                    .padding(horizontal = 16.dp, vertical = 10.dp)
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Filled.Warning,
                                        contentDescription = "Notice",
                                        tint = CyanNeon,
                                        modifier = Modifier.size(18.dp)
                                    )
                                    Text(
                                        text = uiState.userFriendlyMessage!!,
                                        color = TextPrimary,
                                        fontSize = 13.sp,
                                        fontWeight = FontWeight.Medium
                                    )
                                    TextButton(onClick = { viewModel.clearUserMessage() }) {
                                        Text("Dismiss", color = CyanNeon, fontWeight = FontWeight.Bold)
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun VisionTopAppBar(
    activeChannelCount: Int,
    isScanning: Boolean,
    onTriggerScan: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .windowInsetsPadding(WindowInsets.statusBars)
            .padding(horizontal = 16.dp, vertical = 10.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
                modifier = Modifier
                    .size(36.dp)
                    .clip(RoundedCornerShape(10.dp))
                    .background(Color(0xFF111D33))
                    .border(1.dp, Color(0x6600E5FF), RoundedCornerShape(10.dp)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Filled.Tv,
                    contentDescription = "Vision IPTV",
                    tint = CyanNeon,
                    modifier = Modifier.size(20.dp)
                )
            }

            Spacer(modifier = Modifier.width(10.dp))

            Column {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = "VISION",
                        color = TextPrimary,
                        fontSize = 17.sp,
                        fontWeight = FontWeight.ExtraBold,
                        letterSpacing = 1.sp
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = "IPTV",
                        color = CyanNeon,
                        fontSize = 17.sp,
                        fontWeight = FontWeight.ExtraBold,
                        letterSpacing = 1.sp
                    )
                }

                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(6.dp)
                            .background(EmeraldLive, CircleShape)
                    )
                    Spacer(modifier = Modifier.width(5.dp))
                    Text(
                        text = "$activeChannelCount LIVE",
                        color = EmeraldLive,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 0.5.sp
                    )
                }
            }
        }

        // Live Validation Status Icon
        IconButton(
            onClick = onTriggerScan,
            enabled = !isScanning,
            modifier = Modifier
                .size(40.dp)
                .background(Color(0xFF172033), RoundedCornerShape(10.dp))
                .border(1.dp, IptvBorder, RoundedCornerShape(10.dp))
                .testTag("top_scan_quick_action")
        ) {
            Icon(
                imageVector = Icons.Filled.Refresh,
                contentDescription = "Re-check feeds",
                tint = if (isScanning) CyanNeon else TextSecondary,
                modifier = Modifier.size(20.dp)
            )
        }
    }
}
