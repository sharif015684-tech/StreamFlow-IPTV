package com.example.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.AppDatabase
import com.example.data.ChannelRepository
import com.example.model.AdminDashboardStats
import com.example.model.ChannelEntity
import com.example.model.ChannelStatus
import com.example.model.ScanProgressState
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

enum class NavigationTab {
    DASHBOARD,
    LIVE_CHANNELS,
    FAVORITES,
    ADMIN_SCAN,
    SETTINGS
}

data class IptvUiState(
    val currentTab: NavigationTab = NavigationTab.DASHBOARD,
    val selectedCategory: String = "All",
    val searchQuery: String = "",
    val activeChannels: List<ChannelEntity> = emptyList(),
    val featuredChannels: List<ChannelEntity> = emptyList(),
    val recentlyWatched: List<ChannelEntity> = emptyList(),
    val favorites: List<ChannelEntity> = emptyList(),
    val allChannelsForAdmin: List<ChannelEntity> = emptyList(),
    val adminFilter: String = "ALL", // ALL, ACTIVE, INACTIVE, CHECKING
    val selectedChannelForPlayback: ChannelEntity? = null,
    val isPlayerFullScreen: Boolean = false,
    val isAdminMode: Boolean = false,
    val userFriendlyMessage: String? = null
)

internal data class FilterParams(
    val currentTab: NavigationTab = NavigationTab.DASHBOARD,
    val selectedCategory: String = "All",
    val searchQuery: String = "",
    val adminFilter: String = "ALL",
    val selectedChannelForPlayback: ChannelEntity? = null,
    val isPlayerFullScreen: Boolean = false,
    val isAdminMode: Boolean = false,
    val userFriendlyMessage: String? = null
)

class IptvViewModel(application: Application) : AndroidViewModel(application) {

    private val database = AppDatabase.getInstance(application)
    private val repository = ChannelRepository(database.channelDao())

    val scanProgress: StateFlow<ScanProgressState> = repository.scanProgress
    val adminStats: StateFlow<AdminDashboardStats> = repository.adminStats.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = AdminDashboardStats()
    )

    private val _filterParams = MutableStateFlow(FilterParams())

    val uiState: StateFlow<IptvUiState> = combine(
        repository.allChannels,
        _filterParams
    ) { allChannels, filters ->
        val query = filters.searchQuery.trim().lowercase()
        val category = filters.selectedCategory

        // Strict business rule: Only ACTIVE channels are visible to normal users
        val allActive = allChannels.filter { it.status == ChannelStatus.ACTIVE.name }

        val filteredActive = allActive.filter { ch ->
            val matchesCat = if (category == "All") true
            else if (category == "Live Now") true
            else ch.category.equals(category, ignoreCase = true)

            val matchesQuery = if (query.isEmpty()) true
            else ch.name.lowercase().contains(query) ||
                    ch.category.lowercase().contains(query) ||
                    ch.epgTitle.lowercase().contains(query)

            matchesCat && matchesQuery
        }

        val favs = allActive.filter { it.isFavorite }
        val recents = allActive
            .filter { it.lastWatchedTimestamp > 0 }
            .sortedByDescending { it.lastWatchedTimestamp }
        val featured = allActive.filter { it.isFeatured }.ifEmpty { allActive.take(3) }

        val filteredAdmin = allChannels.filter { ch ->
            val matchesFilter = when (filters.adminFilter) {
                "ACTIVE" -> ch.status == ChannelStatus.ACTIVE.name
                "INACTIVE" -> ch.status == ChannelStatus.INACTIVE.name
                "CHECKING" -> ch.status == ChannelStatus.CHECKING.name
                else -> true
            }
            val matchesQuery = if (query.isEmpty()) true
            else ch.name.lowercase().contains(query) ||
                    ch.category.lowercase().contains(query)

            matchesFilter && matchesQuery
        }

        IptvUiState(
            currentTab = filters.currentTab,
            selectedCategory = filters.selectedCategory,
            searchQuery = filters.searchQuery,
            activeChannels = filteredActive,
            featuredChannels = featured,
            recentlyWatched = recents,
            favorites = favs,
            allChannelsForAdmin = filteredAdmin,
            adminFilter = filters.adminFilter,
            selectedChannelForPlayback = filters.selectedChannelForPlayback,
            isPlayerFullScreen = filters.isPlayerFullScreen,
            isAdminMode = filters.isAdminMode,
            userFriendlyMessage = filters.userFriendlyMessage
        )
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = IptvUiState()
    )

    fun selectTab(tab: NavigationTab) {
        _filterParams.value = _filterParams.value.copy(currentTab = tab)
    }

    fun selectCategory(category: String) {
        _filterParams.value = _filterParams.value.copy(selectedCategory = category)
    }

    fun setSearchQuery(query: String) {
        _filterParams.value = _filterParams.value.copy(searchQuery = query)
    }

    fun setAdminFilter(filter: String) {
        _filterParams.value = _filterParams.value.copy(adminFilter = filter)
    }

    fun toggleAdminMode() {
        _filterParams.value = _filterParams.value.copy(isAdminMode = !_filterParams.value.isAdminMode)
    }

    fun playChannel(channel: ChannelEntity) {
        // Enforce smart rule: Never open dead channels in normal user mode
        if (channel.status != ChannelStatus.ACTIVE.name && !_filterParams.value.isAdminMode) {
            _filterParams.value = _filterParams.value.copy(
                userFriendlyMessage = "Channel temporarily unavailable."
            )
            return
        }

        viewModelScope.launch {
            repository.recordWatched(channel.id)
            _filterParams.value = _filterParams.value.copy(
                selectedChannelForPlayback = channel,
                isPlayerFullScreen = true
            )
        }
    }

    fun closePlayer() {
        _filterParams.value = _filterParams.value.copy(
            selectedChannelForPlayback = null,
            isPlayerFullScreen = false
        )
    }

    fun toggleFavorite(channel: ChannelEntity) {
        viewModelScope.launch {
            repository.toggleFavorite(channel.id, !channel.isFavorite)
        }
    }

    fun startValidationScan() {
        viewModelScope.launch {
            repository.startValidation()
        }
    }

    fun recheckDeadChannels() {
        viewModelScope.launch {
            repository.recheckInactiveChannels()
        }
    }

    fun testSingleChannel(channelId: String) {
        viewModelScope.launch {
            repository.testSingleChannel(channelId)
        }
    }

    fun importM3uPlaylist(name: String, content: String) {
        viewModelScope.launch {
            repository.importM3uContent(name, content)
        }
    }

    fun resetToDefaults() {
        viewModelScope.launch {
            repository.resetToDefaultStreams()
        }
    }

    fun clearUserMessage() {
        _filterParams.value = _filterParams.value.copy(userFriendlyMessage = null)
    }
}
