package com.example

import com.example.model.ChannelEntity
import com.example.model.ChannelStatus
import com.example.validator.M3uParser
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class ExampleUnitTest {

    @Test
    fun testM3uParser_extractsValidChannelsAndAttributes() {
        val sampleM3u = """
            #EXTM3U
            #EXTINF:-1 tvg-id="ch1" tvg-name="Sports 1 HD" tvg-logo="https://logo.net/sp1.png" group-title="Sports",Sports 1 HD
            https://secure-iptv-stream.net/live/sp1.m3u8
            #EXTINF:-1 tvg-id="ch2" tvg-name="Cinema 4K" group-title="Movies",Cinema 4K
            https://secure-iptv-stream.net/live/cinema.m3u8
        """.trimIndent()

        val channels = M3uParser.parse(sampleM3u)
        assertEquals(2, channels.size)

        val ch1 = channels[0]
        assertEquals("Sports 1 HD", ch1.name)
        assertEquals("Sports", ch1.category)
        assertEquals("https://logo.net/sp1.png", ch1.logoUrl)
        assertEquals("720p HD", ch1.resolution)

        val ch2 = channels[1]
        assertEquals("Cinema 4K", ch2.name)
        assertEquals("Movies", ch2.category)
        assertEquals("4K UHD", ch2.resolution)
    }

    @Test
    fun testUrlMasking_protectsRawCredentialsAndPrivateSource() {
        val privateUrl = "https://private-iptv-provider.com:8080/live/user123/passSecret/7890.m3u8"
        val masked = ChannelEntity.maskUrl(privateUrl)

        assertFalse(masked.contains("user123"))
        assertFalse(masked.contains("passSecret"))
        assertFalse(masked.contains("7890.m3u8"))
        assertTrue(masked.contains("private-iptv-provider.com"))
        assertTrue(masked.contains("••••••••"))
    }

    @Test
    fun testSmartChannelFiltering_hidesDeadChannelsFromNormalUserView() {
        val activeChannel = ChannelEntity(
            id = "c1",
            name = "Active News",
            streamUrl = "https://cdn.net/active.m3u8",
            status = ChannelStatus.ACTIVE.name,
            isFavorite = true
        )
        val deadChannel = ChannelEntity(
            id = "c2",
            name = "Offline Sports",
            streamUrl = "https://cdn.net/dead.m3u8",
            status = ChannelStatus.INACTIVE.name,
            isFavorite = true // User starred it previously, but now it's dead
        )

        val allChannels = listOf(activeChannel, deadChannel)

        // Strict filtering for normal users
        val userVisibleChannels = allChannels.filter { it.status == ChannelStatus.ACTIVE.name }
        assertEquals(1, userVisibleChannels.size)
        assertEquals("Active News", userVisibleChannels.first().name)

        // Dead channel should NOT appear in user favorites
        val userFavorites = allChannels.filter { it.status == ChannelStatus.ACTIVE.name && it.isFavorite }
        assertEquals(1, userFavorites.size)
        assertEquals("Active News", userFavorites.first().name)
    }
}
